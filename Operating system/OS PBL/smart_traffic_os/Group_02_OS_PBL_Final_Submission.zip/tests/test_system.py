"""System-level tests for the Smart Traffic OS prototype."""

from __future__ import annotations

from collections.abc import Iterable

from concurrency.manager import TrafficBankersAlgorithm
from core.pcb_manager import ExtendedPCB
from memory.virtual_memory import (
    simulate_fifo,
    simulate_lru,
    simulate_optimal,
)
from scheduling.engine import C_SW, ExecutionSlice, simulate_preemptive_priority


def test_preemptive_priority_math() -> None:
    """Verify emergency zero-jitter behavior and penalty-free AWT math."""
    workload = [
        ExtendedPCB(pid="P1", tgid=1, arrival_time=0.0, burst_time=3.0, priority=1),
        ExtendedPCB(pid="P2", tgid=2, arrival_time=1.0, burst_time=5.0, priority=2),
        ExtendedPCB(pid="P3", tgid=3, arrival_time=2.0, burst_time=8.0, priority=3),
        ExtendedPCB(pid="P4", tgid=4, arrival_time=3.0, burst_time=4.0, priority=4),
    ]

    result = simulate_preemptive_priority(workload)

    assert result["process_metrics"]["P1"]["waiting_time"] == 0.0
    assert _average_waiting_without_switch_penalty(
        result["trace"], workload
    ) == 5.25


def test_bankers_deadlock_avoidance() -> None:
    """Reject P4's unsafe corridor request and preserve the original state."""
    banker = TrafficBankersAlgorithm(
        processes=[
            "P1_Ambulance",
            "P2_BRT_Bus",
            "P3_SmartTransit",
            "P4_Logistics",
        ],
        available=[1, 1, 1],
        max_demand={
            "P1_Ambulance": [2, 1, 1],
            "P2_BRT_Bus": [2, 2, 1],
            "P3_SmartTransit": [3, 1, 2],
            "P4_Logistics": [2, 2, 2],
        },
        allocation={
            "P1_Ambulance": [1, 0, 0],
            "P2_BRT_Bus": [1, 1, 0],
            "P3_SmartTransit": [1, 0, 1],
            "P4_Logistics": [0, 1, 1],
        },
    )
    expected_sequence = [
        "P1_Ambulance",
        "P2_BRT_Bus",
        "P3_SmartTransit",
        "P4_Logistics",
    ]
    assert banker.is_safe_state() == expected_sequence

    available_before = banker.available.copy()
    allocation_before = {
        pid: vector.copy() for pid, vector in banker.allocation.items()
    }
    assert banker.request_resources("P4_Logistics", [1, 1, 0]) is False
    assert banker.available == available_before
    assert banker.allocation == allocation_before


def test_page_replacement_optimality() -> None:
    """Verify the expected capacity-three benchmark ordering."""
    pages = [7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1]

    optimal_faults = simulate_optimal(pages, 3)[0]
    lru_faults = simulate_lru(pages, 3)[0]
    fifo_faults = simulate_fifo(pages, 3)[0]

    assert optimal_faults == 9
    assert optimal_faults <= lru_faults < fifo_faults
    assert lru_faults == 12
    assert fifo_faults == 15


def _average_waiting_without_switch_penalty(
    trace: Iterable[ExecutionSlice], workload: Iterable[ExtendedPCB]
) -> float:
    """Compress switch gaps and calculate the trace's penalty-free AWT."""
    durations: dict[str, float] = {}
    for pid, start, end in trace:
        durations[pid] = durations.get(pid, 0.0) + (end - start)

    virtual_time = 0.0
    waiting_times: list[float] = []
    for process in sorted(workload, key=lambda item: (item.arrival_time, item.pid)):
        virtual_time = max(virtual_time, process.arrival_time)
        virtual_time += durations[process.pid]
        waiting_times.append(
            virtual_time - process.arrival_time - process.burst_time
        )
    return sum(waiting_times) / len(waiting_times)